# IEC 61850 Qt Icon Pack

33 original SVG icons with 24x24 viewBox, Qt resource manifest, and Qt Widgets example. No third-party artwork is included. These are UI representations, not IEC standard-defined symbols.

## Build
```bash
cmake -S . -B build
cmake --build build
```

Qt5 or Qt6 Widgets and Svg development modules are required. The demo is UI-only: no MMS protocol implementation, device connections, or control commands.

Resource example: `QIcon(":/iec61850/icons/icons/ied.svg")`.

## Usage
The SVGs are original generated artwork; adapt them for your application. Maintain consistent stroke widths, test 16px rendering, and combine shape with text for status and safety-critical controls. Avoid representing connection success merely by calling a connect action; update from protocol state.
