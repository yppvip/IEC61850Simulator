#include <QApplication>
#include <QMainWindow>
#include <QToolBar>
#include <QTreeWidget>
#include <QDockWidget>
#include <QStatusBar>
#include <QAction>
#include <QIcon>
#include <QString>

static QIcon icon(const char* name) {
    return QIcon(QString(":/iec61850/icons/icons/%1.svg").arg(name));
}

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    QMainWindow window;
    window.setWindowTitle("IEC 61850 Debug Studio - UI Demo");
    auto* toolbar = window.addToolBar("MMS");
    toolbar->setIconSize(QSize(24, 24));
    for (const auto& item : {std::pair{"connect", "Connect"}, {"disconnect", "Disconnect"},
                             {"read", "Read"}, {"write", "Write"},
                             {"server-start", "Start Simulator"}, {"server-stop", "Stop Simulator"}}) {
        auto* action = toolbar->addAction(icon(item.first), item.second);
        action->setToolTip(item.second);
        // Connect each QAction to your MMS client/server controller.
    }
    auto* tree = new QTreeWidget;
    tree->setHeaderLabel("IEC 61850 Model");
    auto* ied = new QTreeWidgetItem(tree, {"IED_01"}); ied->setIcon(0, icon("ied"));
    auto* ld = new QTreeWidgetItem(ied, {"LD0"}); ld->setIcon(0, icon("ld"));
    auto* ln = new QTreeWidgetItem(ld, {"XCBR1"}); ln->setIcon(0, icon("ln"));
    auto* object = new QTreeWidgetItem(ln, {"Pos"}); object->setIcon(0, icon("do"));
    auto* attribute = new QTreeWidgetItem(object, {"stVal"}); attribute->setIcon(0, icon("da"));
    tree->expandAll();
    window.setCentralWidget(tree);
    window.statusBar()->showMessage("UI demonstration only - no MMS connection");
    window.resize(900, 600);
    window.show();
    return app.exec();
}
